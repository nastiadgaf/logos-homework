let mainMenu = document.querySelector('.main-menu');
let mainMenuItem = document.querySelectorAll('.main-menu__item');


 for( let i = 0; i < mainMenuItem.length; i++){
        document.mainMenuItem.append(i);
    }

    console.log(mainMenu);