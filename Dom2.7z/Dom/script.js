const body = document.body;
const menu = body.children[0];
const divlogo = menu.nextElementSibling;
const menu_list = menu.children[0];
const menu_list_item3 = menu_list.children[2];
const table = body.children[2];
const rows = table.rows;
//const td = tr.cells;

for (let cells of rows) {
    console.log(cells);
  }

console.log(menu);
console.log(divlogo);
console.log(menu_list_item3);
console.log(divlogo.parentNode);
console.log(td);