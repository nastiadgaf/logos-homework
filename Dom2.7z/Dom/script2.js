let array = [
    header = document.getElementsByTagName('header'),
    about_us_section = document.querySelector('#about-us'),
    list = document.querySelectorAll('li'),
    about_us = document.querySelector('.about-us__item'),
    parent = about_us.parentNode,
]

console.log(array);



