let footer = document.getElementsByTagName('footer');
footer.remove();
