let mainMenu = document.querySelector('.main-menu');
let footer = document.getElementsByTagName('footer');
let footerMenu = mainMenu.cloneNode(true); 
/*
footer.append(footerMenu);
console.log(footer);*/