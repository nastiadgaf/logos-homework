let array = [
    header = document.getElementsByTagName('header'),
    about_us_section = document.querySelector('#about-us'),
    list = document.querySelectorAll('li'),
    about_us = document.querySelector('.about-us__item'),
    parent = about_us.parentNode,
]

console.log(array);

let mainMenu = document.querySelector('.main-menu');
let footer = document.getElementsByTagName('footer');
let footerMenu = mainMenu.cloneNode(true); 
/*
footer.append(footerMenu);
console.log(footer);*/

let mainMenuItem = document.querySelectorAll('.main-menu__item');


 /*   for( let i = 0; i < mainMenuItem.length; i++){
        document.mainMenuItem.append(i);
    }

    console.log(mainMenu);
*/
footer.remove();


