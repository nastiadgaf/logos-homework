function min(a,b){
    if ( a < b){
        return a;
    } else {
        return b;
    }
}

console.log(min(4,3));