function getPow( x, n){
    return Math.pow(x,n);
}

console.log( getPow (15, 2));