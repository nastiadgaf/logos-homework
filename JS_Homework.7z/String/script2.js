function checkComment(str){
    
}