let str = `Say my\nname`;

console.log(str);
console.log(str.length);
console.log( str.toUpperCase());
console.log( str.toLowerCase());

for ( let symbol of str){
    console.log(symbol);
}