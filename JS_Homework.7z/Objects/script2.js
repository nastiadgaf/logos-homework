const list = {
    1: 'Breaking Bad',
    2: 'Game of Thrones',
    3: 'Lost',
    
  
    push(){
       list.push;
    }

    // Methods
  }
  

  list.push('Eight Sense');
  console.log(list[4]); // Eight Sense
  
 /* list.pop();
  console.log(list[4]); // undefined
  console.log(list[3]); // Lost
  
  list.shift();
  console.log(list[1]); // 'Game of Thrones'
  console.log(list[2]); // 'Lost'
  
  list.unshift('Babylon 5');
  console.log(list[1]); // 'Babylon 5'
  console.log(list[2]); // 'Game of Thrones'*/