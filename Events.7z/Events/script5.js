
const block = document.querySelector('#block');
const arrow = document.querySelector('.arrow');

 function showArrow(){
    arrow.className = 'visible';
}

window.addEventListener( 'scroll' , () => showArrow());