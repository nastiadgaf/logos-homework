const header = document.querySelector('#header');
const list = document.querySelector('#list');
const mainMenuList = document.querySelector('#main_menu_list');
const mainElement = document.querySelector('#main_element');
const image= document.querySelector('#image');
const element = document.querySelectorAll('.element');


function change(){
    element.className = 'new-element';
}

image.addEventListener( "click" , () => change());