const button = document.querySelector('#button');
const text = document.querySelector('#text');
const button2 = document.querySelector('#button2');

button.onclick = function(){
    text.hidden = true;
}

button2.onclick = function(){
    button2.hidden = true;
}



function doAlert(){
    alert("1");
}

button.addEventListener("click", doAlert);

button.removeEventListener("click", doAlert);

button.onclick = () => alert(2);

/*
let text = document.querySelector('#text');
let textarea = document.createElement('textarea');
document.body.append(textarea);
text.addEventListener('focusin', (event) => {
    
});*/