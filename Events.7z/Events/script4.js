const backgroundButton1 = document.querySelector('#button-background1');
const backgroundButton2 = document.querySelector('#button-background2');
const backgroundButton3 = document.querySelector('#button-background3');
const backgroundButton4 = document.querySelector('#button-background4');

const textButton1 = document.querySelector('#button-text1');
const textButton2 = document.querySelector('#button-text2');
const textButton3 = document.querySelector('#button-text3');
const textButton4 = document.querySelector('#button-text4');

const textContent1 = document.querySelector('#text-content1');
const textContent2 = document.querySelector('#text-content2');
const textContent3 = document.querySelector('#text-content3');
const textContent4 = document.querySelector('#text-content4');

const text1 = document.querySelector('#text1');
const text2 = document.querySelector('#text2');
const text3 = document.querySelector('#text3');
const text4 = document.querySelector('#text4');

function changeBackgroundColor1(){
    textContent1.className = 'pink';
}
function changeBackgroundColor2(){
    textContent2.className = 'pink';
}
function changeBackgroundColor3(){
    textContent3.className = 'pink';
}
function changeBackgroundColor4(){
    textContent4.className = 'pink';
}

backgroundButton1.addEventListener( "click" , () => changeBackgroundColor1());
backgroundButton2.addEventListener( "click" , () => changeBackgroundColor2());
backgroundButton3.addEventListener( "click" , () => changeBackgroundColor3());
backgroundButton4.addEventListener( "click" , () => changeBackgroundColor4());

function changeTextColor1(){
    text1.className = 'text-color';
}
function changeTextColor2(){
    text2.className = 'text-color';
}
function changeTextColor3(){
    text3.className = 'text-color';
}
function changeTextColor4(){
    text4.className = 'text-color';
}

textButton1.addEventListener( "click" , () => changeTextColor1());
textButton2.addEventListener( "click" , () => changeTextColor2());
textButton3.addEventListener( "click" , () => changeTextColor3());
textButton4.addEventListener( "click" , () => changeTextColor4());