let images = document.querySelector('#images');
let image = document.querySelectorAll('.image');

images.onclick = function(){
    alert(images.dataset);
};